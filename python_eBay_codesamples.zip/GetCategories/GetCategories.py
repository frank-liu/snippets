###############################################################################
# Author: Michael Hawthornthwaite - Acid Computer Services (www.acidcs.co.uk) #
###############################################################################


#Send Content-type header to browser
print "Content-type: text/html"
print

#import the HTTP, DOM and ConfigParser modules needed
import httplib, ConfigParser, codecs
from xml.dom.minidom import parse, parseString


# open config file
config = ConfigParser.ConfigParser()
config.read("config.ini")

# specify eBay API dev,app,cert IDs
devID = config.get("Keys", "Developer")
appID = config.get("Keys", "Application")
certID = config.get("Keys", "Certificate")

#get the server details from the config file
serverUrl = config.get("Server", "URL")
serverDir = config.get("Server", "Directory")


# specify eBay token
# note that eBay requires encrypted storage of user data
userToken = config.get("Authentication", "Token")


#eBay Call Variables
#siteID specifies the eBay international site to associate the call with
#0 = US, 2 = Canada, 3 = UK, ....
siteID = "0"
#verb specifies the name of the call
verb = "GetCategories"
#The API level that the application conforms to
compatabilityLevel = "433"


#stores the category tree DOM object
global catTree

#the location of the local copy of the tree
catTreeFile = "CatTree.xml"



#Setup the HTML Page with name of call as title
print "<HTML>"
print "<HEAD><TITLE>", verb, "</TITLE></HEAD>"
print "<BODY>"

#FUNCTION: getEntireCategoryTree
# requests the entire cateogory tree and saves it locally
def getEntireCategoryTree():
    # specify the connection to the eBay environment
    connection = httplib.HTTPSConnection(serverUrl)
    # specify a POST with the results of generateHeaders and generateRequest
    # detailLevel = 1, ViewAllNodes = 1  - this gets the entire tree
    connection.request("POST", serverDir, buildRequestXml("ReturnAll", "1"), buildHttpHeaders())
    response = connection.getresponse()
    if response.status != 200:
        print "Error sending request for entire tree: " + response.reason
        exit
    else: #response successful
        # store the response data
        data = response.read()
        # parse the response data into a DOM
        catTree = parseString(data)
        #uData = unicode(data)
        fileObj = open( catTreeFile, "w")
        fileObj.write(data)
        fileObj.close()
    # close the connection
    connection.close()


# FUNCTION getOnlineVersion
# requests and returns the current version number of the category tree available from the API
def getOnlineVersion():
    # specify the connection to the eBay environment
    connection = httplib.HTTPSConnection(serverUrl)
    # specify a POST with the results of generateHeaders and generateRequest
    # detailLevel = 0, ViewAllNodes = 0  - this gets only Verison number
    connection.request("POST", serverDir, buildRequestXml("", "0"), buildHttpHeaders())
    response = connection.getresponse()
    if response.status != 200:
        print "Error sending request for tree version: " + response.reason
        exit
    else: #response successful
        # store the response data
        data = response.read()
        # parse the response data into a DOM
        response = parseString(data)
        onlineVersionNum = ((response.getElementsByTagName('CategoryVersion')[0]).childNodes[0]).nodeValue
    # close the connection
    connection.close()
    return onlineVersionNum


# FUNCTION: buildHttpHeaders
# Build together the required headers for the HTTP request to the eBay API
def buildHttpHeaders():
    httpHeaders = {"X-EBAY-API-COMPATIBILITY-LEVEL": compatabilityLevel,
               "X-EBAY-API-DEV-NAME": devID,
               "X-EBAY-API-APP-NAME": appID,
               "X-EBAY-API-CERT-NAME": certID,
               "X-EBAY-API-CALL-NAME": verb,
               "X-EBAY-API-SITEID": siteID,
               "Content-Type": "text/xml"}
    return httpHeaders

# FUNCTION: buildRequestXml
# Build the body of the call (in XML) incorporating the required parameters to pass
def buildRequestXml(detailLevel, viewAllNodes):
    requestXml = "<?xml version='1.0' encoding='utf-8'?>"+\
              "<GetCategoriesRequest xmlns=\"urn:ebay:apis:eBLBaseComponents\">"+\
              "<RequesterCredentials><eBayAuthToken>" + userToken + "</eBayAuthToken></RequesterCredentials>"
    
    if (detailLevel != ""):
        requestXml = requestXml + "<DetailLevel>" + detailLevel + "</DetailLevel>"
                     
    requestXml = requestXml + "<Item><Site>" + siteID + "</Site></Item>"+\
              "<ViewAllNodes>" + viewAllNodes + "</ViewAllNodes>"+\
              "</GetCategoriesRequest>"
    return requestXml



# FUNCTION: fileExists
# Returns 0 if file specified does not exist, return 1 if it does
def fileExists(f):
    try:
        file = open(f)
    except IOError:
        return 0
    else:
        return 1


# see if the local CatTree file exists
if fileExists(catTreeFile) == 0:
    # file does not exists: download and save it
    getEntireCategoryTree()
    print "<P><B>New category tree downloaded</B>"
else: #File does exist - make sure it is latest version
    # get online version number
    onlineVersion = getOnlineVersion()
    # open file and get local version number
    fileObj = open(catTreeFile, 'r')
    catTree = parseString(fileObj.read())
    fileObj.close()
    localVersion = ((catTree.getElementsByTagName('CategoryVersion')[0]).childNodes[0]).nodeValue
    #if verion numbers do not match then local version is out of date
    if(onlineVersion != localVersion):
        #download and save category tree
        getEntireCategoryTree()
        print "<P><B>New category tree downloaded</B>"
    else: #all up to date
        print "<P><B>Category tree is up to date</B>"



#get the tree for displaying
fileObj = open(catTreeFile, 'r')
catTree = parseString(fileObj.read())
fileObj.close()


#print out all the top-level categories
print "<P><B>TOP-LEVEL CATEGORIES</B>"
#get all of the categories
categories = catTree.getElementsByTagName('Category')
#go through each cateogyr
for cat in categories:
    #get the categories ID and ParentID
    catId = ((cat.getElementsByTagName('CategoryID')[0]).childNodes[0]).nodeValue
    catParentId = ((cat.getElementsByTagName('CategoryParentID')[0]).childNodes[0]).nodeValue
    #if ID = ParentID then it is a Top-Level Node
    if(catId == catParentId):
        #print the category name and ID
        catName = ((cat.getElementsByTagName('CategoryName')[0]).childNodes[0]).nodeValue
        print "<BR>" + catName + " (" + catId + ")"
                            
    



         
# force garbage collection of the DOM object
if catTree != None:
    catTree.unlink()


#finish HTML page
print "</BODY>"
print "</HTML>"

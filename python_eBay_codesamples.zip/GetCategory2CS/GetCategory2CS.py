###############################################################################
# Author: Michael Hawthornthwaite - Acid Computer Services (www.acidcs.co.uk) #
###############################################################################


#Send Content-type header to browser
print "Content-type: text/html"
print

#import the HTTP, DOM and ConfigParser modules needed
import httplib, ConfigParser, codecs
from xml.dom.minidom import parse, parseString


# open config file
config = ConfigParser.ConfigParser()
config.read("config.ini")

# specify eBay API dev,app,cert IDs
devID = config.get("Keys", "Developer")
appID = config.get("Keys", "Application")
certID = config.get("Keys", "Certificate")

#get the server details from the config file
serverUrl = config.get("Server", "URL")
serverDir = config.get("Server", "Directory")


# specify eBay token
# note that eBay requires encrypted storage of user data
userToken = config.get("Authentication", "Token")


#eBay Call Variables
#siteID specifies the eBay international site to associate the call with
#0 = US, 2 = Canada, 3 = UK, ....
siteID = "0"
#verb specifies the name of the call
verb = "GetCategory2CS"
#The API level that the application conforms to
compatabilityLevel = "433"


#stores the category map DOM object
global catMap

#the location of the local copy of the map
catMapFile = "CatMap.xml"



#Setup the HTML Page with name of call as title
print "<HTML>"
print "<HEAD><TITLE>", verb, "</TITLE></HEAD>"
print "<BODY>"

# FUNCTION: getEntireCategoryMap
# requests the entire cateogory map and saves it locally
def getEntireCategoryMap():
    # specify the connection to the eBay environment
    connection = httplib.HTTPSConnection(serverUrl)
    # specify a POST with the results of generateHeaders and generateRequest
    # detailLevel = 1 - this gets the entire map
    connection.request("POST", serverDir, buildRequestXml("ReturnAll"), buildHttpHeaders())
    response = connection.getresponse()
    if response.status != 200:
        print "Error sending request for entire tree: " + response.reason
        exit
    else: #response successful
        # store the response data
        data = response.read()
        # parse the response data into a DOM
        catMap = parseString(data)
        #uData = unicode(data)
        fileObj = open( catMapFile, "w")
        fileObj.write(data)
        fileObj.close()
    # close the connection
    connection.close()


# FUNCTION getOnlineVersion
# requests and returns the current version number of the category map available from the API
def getOnlineVersion():
    # specify the connection to the eBay environment
    connection = httplib.HTTPSConnection(serverUrl)
    # specify a POST with the results of generateHeaders and generateRequest
    # detailLevel = 0 - this gets only Verison number
    connection.request("POST", serverDir, buildRequestXml(""), buildHttpHeaders())
    response = connection.getresponse()
    if response.status != 200:
        print "Error sending request for tree version: " + response.reason
        exit
    else: #response successful
        # store the response data
        data = response.read()
        # parse the response data into a DOM
        response = parseString(data)
        onlineVersionNum = ((response.getElementsByTagName('AttributeSystemVersion')[0]).childNodes[0]).nodeValue
    # close the connection
    connection.close()
    return onlineVersionNum


# FUNCTION: buildHttpHeaders
# Build together the required headers for the HTTP request to the eBay API
def buildHttpHeaders():
    httpHeaders = {"X-EBAY-API-COMPATIBILITY-LEVEL": compatabilityLevel,
               "X-EBAY-API-DEV-NAME": devID,
               "X-EBAY-API-APP-NAME": appID,
               "X-EBAY-API-CERT-NAME": certID,
               "X-EBAY-API-CALL-NAME": verb,
               "X-EBAY-API-SITEID": siteID,
               "Content-Type": "text/xml"}
    return httpHeaders

# FUNCTION: buildRequestXml
# Build the body of the call (in XML) incorporating the required parameters to pass
def buildRequestXml(detailLevel):
    requestXml = "<?xml version='1.0' encoding='utf-8'?>"+\
              "<GetCategory2CSRequest xmlns=\"urn:ebay:apis:eBLBaseComponents\">"+\
              "<RequesterCredentials><eBayAuthToken>" + userToken + "</eBayAuthToken></RequesterCredentials>"
    
    if (detailLevel != ""):
        requestXml = requestXml + "<DetailLevel>" + detailLevel + "</DetailLevel>"
                     
    requestXml = requestXml + "<Item><Site>" + siteID + "</Site></Item>"+\
              "</GetCategory2CSRequest>"
    return requestXml



# FUNCTION: fileExists
# Returns 0 if file specified does not exist, return 1 if it does
def fileExists(f):
    try:
        file = open(f)
    except IOError:
        return 0
    else:
        return 1

# see if the local CatMap file exists
if fileExists(catMapFile) == 0:
    # file does not exists: download and save it
    getEntireCategoryMap()
    print "<P><B>New category map downloaded</B>"
else: #File does exist - make sure it is latest version
    # get online version number
    onlineVersion = getOnlineVersion()
    # open file and get local version number
    fileObj = open(catMapFile, 'r')
    catMap = parseString(fileObj.read())
    fileObj.close()
    localVersion = ((catMap.getElementsByTagName('AttributeSystemVersion')[0]).childNodes[0]).nodeValue
    #if verion numbers do not match then local version is out of date
    if(onlineVersion != localVersion):
        #download and save category map
        getEntireCategoryMap()
        print "<P><B>New category map downloaded</B>"
    else: #all up to date
        print "<P><B>Category map is up to date</B>"





#get the map for displaying
fileObj = open(catMapFile, 'r')
catMap = parseString(fileObj.read())
fileObj.close()



#get the mapped categoires
mappedNode = catMap.getElementsByTagName('MappedCategoryArray');
if mappedNode != [] and mappedNode[0].childNodes != []:
    print "<P><B>MAPPED:</B>"
    cats = mappedNode[0].getElementsByTagName('Category');
    #go through each category
    for cat in cats:
        #get and output details
        catId = ((cat.getElementsByTagName('CategoryID')[0]).childNodes[0]).nodeValue
        csId = ((cat.getElementsByTagName('AttributeSetID')[0]).childNodes[0]).nodeValue
        version = ((cat.getElementsByTagName('AttributeSetVersion')[0]).childNodes[0]).nodeValue
        name = ((cat.getElementsByTagName('Name')[0]).childNodes[0]).nodeValue
        print "<BR>Category ID: ", catId
        print "<BR>&nbsp;&nbsp;&nbsp;&nbsp;Att. Set ID:", csId, ", Name:", csId, ", Version: ", version

#get unmapped categories
unmappedNode = catMap.getElementsByTagName('UnmappedCategoryArray');
if unmappedNode != [] and unmappedNode[0].childNodes != []:
    print "<P><B>UNMAPPED:</B>"
    cats = unmappedNode[0].getElementsByTagName('Category');
    #go through each category
    for cat in cats:
        #output category id
        catId = ((cat.getElementsByTagName('CategoryID')[0]).childNodes[0]).nodeValue
        print "<BR>Category ID: ", catId


#Get the site wide CSs
siteWideCS = catMap.getElementsByTagName('SiteWideCharacteristicSets');
if siteWideCS != [] and siteWideCS[0].childNodes != []:
    print "<P><B>SITE-WIDE:</B>"
    CSs = siteWideCS[0].getElementsByTagName('CharacteristicsSet');
    #go through each CS
    for cs in CSs:
        #print its CSId and Version
        csId = ((cat.getElementsByTagName('AttributeSetID')[0]).childNodes[0]).nodeValue
        version = ((cat.getElementsByTagName('AttributeSetVersion')[0]).childNodes[0]).nodeValue
        name = ((cat.getElementsByTagName('Name')[0]).childNodes[0]).nodeValue
        print "<P>Att. Set ID:: ", csId, ", Name: ", name, ", Version: ", version
        
    





         
# force garbage collection of the DOM object
if catMap != None:
    catMap.unlink()


#finish HTML page
print "</BODY>"
print "</HTML>"

This example demonstrates techniques for downloading, saving and keeping up-to-date the local copy of the Category-to-CS Map. It then displays all of the mapping details. When creating a real-world application you will not need to check the online version number every time the code is executed.

To get started with this example you must open the config.ini file and edit the variables as follows:
Developer - Your Developer ID
Application - Your Application ID
Certificate - Your Certificate ID
URL - The URL of the eBay server you wish to use (Snadbox or Production)
Token - The Authentication token representing the eBay user who is making the call
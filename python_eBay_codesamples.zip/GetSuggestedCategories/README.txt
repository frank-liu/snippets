This example allows the user to enter a keyword query and then displays up to 10 suggested categories based on the query.

To get started with this example you must open the config.ini file and edit the variables as follows:
Developer - Your Developer ID
Application - Your Application ID
Certificate - Your Certificate ID
URL - The URL of the eBay server you wish to use (Snadbox or Production)
Token - The Authentication token representing the eBay user who is making the call